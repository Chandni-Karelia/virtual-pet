// 3D pets: draws a glTF model (from window.PET_MODELS, see tools/vendor3d.py) into one transparent canvas
// with three.js and plays its animations. The engine treats it like a video clip that every pose shares:
// setPose() asks for an animation, and the head is tracked so speech bubbles and hearts follow it.
(function (root) {
'use strict';

// the canvas covers a fixed slice of the scene, like a clip frame: VIEW_H units tall, the model 1 unit tall at rest
const VIEW_H = 1.45, GROUND = .05, TURN = .5;   // TURN: radians of three-quarter view, so he reads as 3D

function decode(b64) {
  const bin = atob(b64), out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out.buffer;
}

function Pet3D(id, canvas, { w, h }) {
  const THREE = root.THREE;
  const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true, preserveDrawingBuffer: false });
  renderer.setClearColor(0x000000, 0);
  const scene = new THREE.Scene();
  // warm, soft light that matches the app: sky and floor tints plus a key light from the front-left
  scene.add(new THREE.HemisphereLight(0xfff3e2, 0x9a7a62, 2.2));
  const key = new THREE.DirectionalLight(0xffffff, 2.4); key.position.set(4, 6, 3); scene.add(key);
  const rim = new THREE.DirectionalLight(0xffe2c4, .9); rim.position.set(-4, 3, -4); scene.add(rim);
  const viewW = VIEW_H * w / h;
  const camera = new THREE.OrthographicCamera(-viewW / 2, viewW / 2, VIEW_H / 2, -VIEW_H / 2, .1, 50);
  camera.position.set(10, VIEW_H / 2 - GROUND, 0); camera.lookAt(0, VIEW_H / 2 - GROUND, 0);

  const api = { ready: null, speed: {}, clips: [], head: [.2, .3], mouth: [.12, .4] };
  let model = null, mixer = null, current = null, headBone = null;
  const actions = {};

  api.ready = new Promise((resolve, reject) => {
    new THREE.GLTFLoader().parse(decode(root.PET_MODELS[id]), '', gltf => {
      model = gltf.scene;
      model.traverse(o => { if (o.isMesh) { o.frustumCulled = false; if (o.material) o.material.side = THREE.FrontSide; } });
      mixer = new THREE.AnimationMixer(model);
      // Quaternius files list every clip twice ("Walk" and "AnimalArmature|Walk"); keep the short names
      for (const clip of gltf.animations) if (!clip.name.includes('|')) actions[clip.name] = mixer.clipAction(clip);
      api.clips = Object.keys(actions);
      // size him to 1 unit tall standing, feet on the ground, centred, facing +Z (which the camera shows as facing left)
      if (actions.Idle) { actions.Idle.play(); mixer.update(0); }
      const box = new THREE.Box3().setFromObject(model), size = box.getSize(new THREE.Vector3());
      const s = 1 / size.y; model.scale.setScalar(s);
      const box2 = new THREE.Box3().setFromObject(model), c = box2.getCenter(new THREE.Vector3());
      model.position.set(-c.x, -box2.min.y, -c.z);
      if (actions.Idle) actions.Idle.stop();
      // how fast the paws travel along the ground in each moving clip (measured before the 3/4 turn), so the engine moves him without sliding
      for (const name of ['Walk', 'Gallop']) if (actions[name]) api.speed[name] = stride(name) * Math.cos(TURN) * w / viewW;
      const pivot = new THREE.Group(); pivot.add(model); pivot.rotation.y = TURN; scene.add(pivot);
      model.traverse(o => { if (o.isBone && o.name === 'Head') headBone = o; });
      resolve(api);
    }, reject);
  });

  // sample a paw's forward position over one cycle: the distance it travels back while planted, per second
  function stride(name) {
    const a = actions[name], clip = a.getClip(), paw = model.getObjectByName('FrontLowerLeg.L_end') || model.getObjectByName('BackLowerLeg.L_end');
    if (!paw) return 0;
    a.reset().play(); const v = new THREE.Vector3(); let lo = Infinity, hi = -Infinity;
    for (let i = 0; i <= 40; i++) {
      mixer.setTime(clip.duration * i / 40); model.updateMatrixWorld(true);
      paw.getWorldPosition(v); lo = Math.min(lo, v.z); hi = Math.max(hi, v.z);
    }
    a.stop();
    return (hi - lo) / (clip.duration * .55);   // a paw is planted for about 55% of the cycle
  }

  // play an animation; once: hold its last frame (lying down); speed: playback rate
  api.play = (name, { once = false, speed = 1, fade = .28 } = {}) => {
    if (!mixer) return;
    const next = actions[name] || actions.Idle;
    if (!next) return;
    next.timeScale = speed;
    if (next === current) return;
    next.reset(); next.setLoop(once ? THREE.LoopOnce : THREE.LoopRepeat, Infinity); next.clampWhenFinished = once;
    next.enabled = true;
    if (current) current.crossFadeTo(next, fade, false);
    next.play(); current = next;
  };
  api.rate = r => { if (current) current.timeScale = r; };

  const v = new THREE.Vector3();
  api.update = dt => {
    if (!mixer) return;
    mixer.update(dt);
    renderer.render(scene, camera);
    if (headBone) {   // where his head is in the frame, for bubbles, hearts and where his mouth meets a bowl
      headBone.getWorldPosition(v); v.project(camera);
      api.head = [(v.x + 1) / 2, (1 - v.y) / 2];
      api.mouth = [api.head[0] - .03, api.head[1] + .09];
    }
  };
  api.resize = (cssW, cssH, dpr) => { renderer.setPixelRatio(dpr); renderer.setSize(cssW, cssH, false); };
  api.dispose = () => { mixer && mixer.stopAllAction(); renderer.dispose(); };
  return api;
}
Pet3D.FOOT_Y = 1 - GROUND / VIEW_H;

root.Pet3D = Pet3D;
})(window);
