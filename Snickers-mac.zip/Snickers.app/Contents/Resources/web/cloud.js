// Opt-in weekly leaderboard: sends the day's score and earned badges to Supabase and reads the ranking.
// Plain fetch against Supabase's REST endpoints (no SDK, so the app stays a few local files).
// Players are anonymous Supabase users; the tables and their security rules are in server/schema.sql.
(function (root) {
'use strict';

const CFG = root.SNICKERS_CLOUD || {};
const KEY = 'biscuit.cloud';
const load = () => { try { return JSON.parse(localStorage.getItem(KEY)) || null; } catch (e) { return null; } };
const save = s => { try { s ? localStorage.setItem(KEY, JSON.stringify(s)) : localStorage.removeItem(KEY); } catch (e) {} };
let sess = load();   // { access_token, refresh_token, expires_at, user_id, nickname, dog_name, breed, league }

const configured = () => !!(CFG.url && CFG.key);

async function raw(path, { method = 'GET', body, token, prefer } = {}) {
  const headers = { apikey: CFG.key, 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  if (prefer) headers.Prefer = prefer;
  const r = await fetch(CFG.url + path, { method, headers, body: body == null ? undefined : JSON.stringify(body) });
  const text = await r.text();
  let data = null; try { data = text ? JSON.parse(text) : null; } catch (e) { data = text; }
  if (!r.ok) {
    const e = new Error((data && (data.message || data.msg || data.error_description || data.error)) || r.statusText || 'Network error');
    e.status = r.status; throw e;
  }
  return data;
}
function keep(t) {
  sess = { ...(sess || {}), access_token: t.access_token, refresh_token: t.refresh_token,
    expires_at: Date.now() + (t.expires_in || 3600) * 1000, user_id: (t.user && t.user.id) || (sess && sess.user_id) };
  save(sess);
}
// a fresh access token (they last an hour; the refresh token keeps the same anonymous player)
async function token() {
  if (sess.expires_at - Date.now() < 60000) keep(await raw('/auth/v1/token?grant_type=refresh_token', { method: 'POST', body: { refresh_token: sess.refresh_token } }));
  return sess.access_token;
}
const call = async (path, opts = {}) => raw(path, { ...opts, token: await token() });

// join: an anonymous player plus a public nickname. Running it again just updates the profile.
async function join({ nickname, dog_name, breed, league }) {
  if (!sess || !sess.refresh_token) { sess = null; keep(await raw('/auth/v1/signup', { method: 'POST', body: { data: {} } })); }
  const profile = { nickname: nickname.trim(), dog_name: (dog_name || 'Snickers').trim(), breed: breed || 'German Shepherd', league: league ? league.trim().toUpperCase() : null };
  await call('/rest/v1/players?on_conflict=id', { method: 'POST', body: { id: sess.user_id, ...profile }, prefer: 'resolution=merge-duplicates,return=minimal' });
  sess = { ...sess, ...profile }; save(sess);
}
async function update(fields) {
  if (!joined()) return;
  await call(`/rest/v1/players?id=eq.${sess.user_id}`, { method: 'PATCH', body: fields, prefer: 'return=minimal' });
  sess = { ...sess, ...fields }; save(sess);
}
// days: [{ day, score, categories, streak }] (today, plus yesterday's final score); badges: [{ id, unlocked }]
async function push(days, badges) {
  if (!joined()) return;
  const id = sess.user_id;
  if (days.length) await call('/rest/v1/daily_scores?on_conflict=player_id,day', { method: 'POST',
    body: days.map(d => ({ player_id: id, day: d.day, score: d.score, categories: d.categories, streak: d.streak })), prefer: 'resolution=merge-duplicates,return=minimal' });
  if (badges.length) await call('/rest/v1/badges?on_conflict=player_id,badge', { method: 'POST',
    body: badges.map(b => ({ player_id: id, badge: b.id, earned_on: b.unlocked })), prefer: 'resolution=ignore-duplicates,return=minimal' });
}
const board = (scope = 'global') => call('/rest/v1/rpc/leaderboard', { method: 'POST', body: { scope, top: 20 } });
// leave: deletes the player and everything they shared, then forgets the session on this Mac
async function leave() {
  if (sess && sess.refresh_token) await call('/rest/v1/rpc/delete_me', { method: 'POST', body: {} });
  sess = null; save(null);
}
function joined() { return !!(sess && sess.nickname && sess.refresh_token); }

root.Cloud = { configured, joined, join, update, push, board, leave, get me() { return sess; } };
})(window);
