// Supabase project for the opt-in leaderboard. The publishable (anon) key is meant to ship inside apps:
// the database's security rules (server/schema.sql) decide what it can do. Leave key empty to turn leaderboards off.
window.SNICKERS_CLOUD = { url: 'https://zjrcqmbvyamnjxxsbrva.supabase.co', key: 'sb_publishable_Jblk6m54uscKMjwTQQrU_A_YE9Hjdqs' };
