// Care state for v1: six needs that drain on a workday rhythm, the actions that meet them,
// gentle neglect (he never gets sick), vacation mode and the local Pet Parent Score.
// Pure logic with the clock passed in, so it runs in node too (tests/care.test.js).
// The numbers are explained in docs/V1_CARE_SPEC.md — keep the two in step.
(function (root) {
'use strict';

const MIN = 60e3, HOUR = 60 * MIN;

// drain: points per hour while he's awake · askAt: he asks below this · gain: what one action adds · cap: counted actions a day
const NEEDS = {
  food:      { label: 'Food', drain: 15, askAt: 35, gain: 70,  cap: 4 },
  water:     { label: 'Water', drain: 25, askAt: 40, gain: 80,  cap: 8 },
  potty:     { label: 'Potty', drain: 22, askAt: 30, gain: 100, cap: 8 },
  play:      { label: 'Play', drain: 8,  askAt: 40, gain: 25,  cap: 8 },
  sleep:     { label: 'Rest', drain: 6,  askAt: 30, gain: 0,   cap: 3, restPerHour: 45 },
  affection: { label: 'Affection', drain: 10, askAt: 40, gain: 12,  cap: 20 },
};
const WEIGHTS = { nutrition: .25, potty: .20, play: .15, sleep: .15, affection: .10, consistency: .15 };
// Pet Parent Score tiers (the same names the leagues will use)
const TIERS = [[0, 'Puppy'], [50, 'Good Boy'], [70, 'Top Dog'], [85, 'Best in Show']];
const active = d => Object.values(d.actions).some(n => n > 0);
// v1 badges (docs/V1_CARE_SPEC.md §6), plus the ones that arrive with calendar and leagues, shown locked so people can see what's ahead.
// value(c) reads the care model; run(pred, broken) counts days in a row ending today (today may still be pending unless it's broken)
const BADGES = [
  { id: 'first-walk', name: 'First Walk', icon: 'paws', how: 'Take him out for the first time', goal: 1, value: c => c.totals.potty },
  { id: 'good-morning', name: 'Good Morning', icon: 'sun', how: 'Feed him before 10 am, 7 days in a row', goal: 7, value: c => c.run(d => d.firstMeal != null && d.firstMeal < 10) },
  { id: 'fetch-champion', name: 'Fetch Champion', icon: 'ball', how: 'Play 100 games of fetch', goal: 100, value: c => c.totals.fetches },
  { id: 'clean-paws', name: 'Clean Paws', icon: 'sparkle', how: '30 days in a row without an accident', goal: 30, value: c => c.run(d => active(d) && d.accidents === 0, d => d.accidents > 0) },
  { id: 'hydration-hero', name: 'Hydration Hero', icon: 'water', how: 'Keep his water topped up, 14 days in a row', goal: 14, value: c => c.run(d => active(d) && !d.waterLow, d => d.waterLow) },
  { id: 'bedtime-pro', name: 'Bedtime Pro', icon: 'moon', how: 'Put him to bed between 9 and 11:30 pm, 7 nights in a row', goal: 7, value: c => c.run(d => d.bedtime != null) },
  { id: 'zoomies-master', name: 'Zoomies Master', icon: 'zoom', how: 'Set off 50 rounds of zoomies', goal: 50, value: c => c.totals.zoomies },
  { id: 'streak-30', name: '30-Day Streak', icon: 'flame', how: 'Care for him 30 days in a row', goal: 30, value: c => c.streak() },
  { id: 'meeting-buddy', name: 'Meeting Buddy', icon: 'calendar', how: 'Accept 20 meeting reminders', goal: 20, soon: 'Arrives with calendar reminders' },
  { id: 'best-in-show', name: 'Best in Show', icon: 'trophy', how: 'Finish in the top 10% of your league', goal: 1, soon: 'Arrives with leagues' },
];
const CATEGORY_LABELS = { nutrition: 'Nutrition', potty: 'Potty', play: 'Play', sleep: 'Sleep', affection: 'Affection', consistency: 'Consistency' };
const RULES = {
  needed: 75,            // an action only scores if the meter was below this
  noGainAbove: 90,       // no effect at all above this (spam-clicking does nothing)
  // scoring is deliberately moderate: reacting late keeps you around Good Boy/Top Dog; Best in Show takes looking after him before he asks, every day
  goodAverage: 80,       // a daily average at or above this is a perfect "care" mark
  careWeight: .55,       // the rest of each need's score is timeliness
  lateFloor: .25, lateSpan: .5,   // an action after he asked is worth 25–75% (on time is 100%)
  idleTimely: .4,        // a need you never tended today counts as 40% timely, not full marks
  quietFrom: 23, quietTo: 7, quietDrain: .1,
  sleepingDrain: .5,
  maxGap: 15 * MIN,      // app closed: never drain more than this per tick
  askEvery: 25 * MIN, laterSnooze: 20 * MIN,
  mopeyBelow: 15, mopeyAverage: 35,
  accidentPenalty: 20, streakFull: 7, historyDays: 60,
  vacationFloor: 70,
};

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const pad = n => String(n).padStart(2, '0');
const dayKey = t => { const d = new Date(t); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const nextDay = key => { const [y, m, d] = key.split('-').map(Number); return dayKey(new Date(y, m - 1, d + 1, 12).getTime()); };
const prevDay = key => { const [y, m, d] = key.split('-').map(Number); return dayKey(new Date(y, m - 1, d - 1, 12).getTime()); };
const each = fn => Object.fromEntries(Object.keys(NEEDS).map(k => [k, fn(k)]));

function newDay(key) {
  return { date: key, awakeMs: 0, vacMs: 0, level: each(() => 0), acts: each(() => 0), timely: each(() => 0), counted: each(() => 0),
    good: 0, junk: 0, accidents: 0, fetches: 0, zoomies: 0, firstMeal: null, bedtime: null, waterLow: false };
}

function create(now, saved) {
  const s = saved && saved.v === 1 ? saved : null;
  const st = s ? JSON.parse(JSON.stringify(s)) : {
    v: 1, meters: each(() => 85), last: now, vacation: false, snooze: each(() => 0),
    day: newDay(dayKey(now)), history: [], totals: { fetches: 0, zoomies: 0, potty: 0 },
  };
  if (!st.snooze) st.snooze = each(() => 0);
  if (!st.badges) st.badges = {};
  if (!st.born) st.born = st.history.length ? st.history[0].date : st.day.date;   // the day he arrived

  // close finished days (and any days the app wasn't opened) into history
  function rollover(t) {
    const today = dayKey(t);
    while (st.day.date < today) {
      const d = st.day, rec = score();
      rec.vacation = d.vacMs > 0 && d.vacMs >= d.awakeMs;
      st.history.push(rec);
      if (st.history.length > RULES.historyDays) st.history.splice(0, st.history.length - RULES.historyDays);
      st.day = newDay(nextDay(d.date));
      if (st.vacation) st.day.vacMs = 1;   // a skipped day while on vacation still counts as vacation
    }
  }

  function tick(t, opts = {}) {
    rollover(t);
    const dt = clamp(t - st.last, 0, RULES.maxGap); st.last = t;
    const events = [];
    if (!dt) return events;
    if (st.vacation) { st.day.vacMs += dt; return events; }
    const h = new Date(t).getHours();
    const quiet = RULES.quietFrom > RULES.quietTo ? (h >= RULES.quietFrom || h < RULES.quietTo) : (h >= RULES.quietFrom && h < RULES.quietTo);
    const hours = dt / HOUR;
    for (const k in NEEDS) {
      const N = NEEDS[k];
      let rate = -N.drain * (quiet ? RULES.quietDrain : 1);
      if (opts.sleeping) rate = k === 'sleep' ? N.restPerHour : rate * RULES.sleepingDrain;
      st.meters[k] = clamp(st.meters[k] + rate * hours, 0, 100);
    }
    if (!quiet) {
      st.day.awakeMs += dt;
      for (const k in NEEDS) st.day.level[k] += st.meters[k] * dt;
      if (st.meters.water < NEEDS.water.askAt) st.day.waterLow = true;
    }
    if (st.meters.potty <= 0) {
      st.meters.potty = 100; st.day.accidents++;
      events.push({ type: 'accident' });
    }
    return events;
  }

  // a care action. Returns { scored, gain } — scored is false when it wasn't needed or the daily cap is hit
  function act(need, t, opts = {}) {
    rollover(t);
    const N = NEEDS[need], m = st.meters[need];
    if (!N) return { scored: false, gain: 0 };
    let gain = need === 'food' && opts.junk ? 55 : need === 'sleep' ? 15 : N.gain;
    if (opts.small) gain = opts.small;
    const needed = m < RULES.needed && !st.vacation;
    if (!needed) gain = m >= RULES.noGainAbove ? 0 : gain / 2;
    st.meters[need] = clamp(m + gain, 0, 100);
    st.snooze[need] = 0;
    const d = st.day;
    if (need === 'food' && !opts.small) { opts.junk ? d.junk++ : d.good++; if (d.firstMeal == null) d.firstMeal = new Date(t).getHours() + new Date(t).getMinutes() / 60; }
    if (need === 'sleep' && opts.bed) { const hh = new Date(t).getHours() + new Date(t).getMinutes() / 60; if (hh >= 21 && hh <= 23.5) d.bedtime = hh; }
    if (need === 'play') { if (opts.kind === 'fetch') { d.fetches++; st.totals.fetches++; } if (opts.kind === 'zoomies') { d.zoomies++; st.totals.zoomies++; } }
    if (need === 'potty') st.totals.potty++;
    d.acts[need]++;
    const scored = needed && !opts.small && d.counted[need] < N.cap;
    if (scored) {
      d.counted[need]++;
      d.timely[need] += m >= N.askAt ? 1 : RULES.lateFloor + RULES.lateSpan * m / N.askAt;
    }
    return { scored, gain };
  }

  // the most urgent need he should ask about right now (and mark it asked), or null
  function dueAsk(t) {
    if (st.vacation) return null;
    let best = null, bestR = Infinity;
    for (const k in NEEDS) {
      const N = NEEDS[k], m = st.meters[k];
      if (m >= N.askAt || t < st.snooze[k]) continue;
      const r = m / N.askAt - (k === 'potty' ? .5 : 0);
      if (r < bestR) { best = k; bestR = r; }
    }
    if (best) st.snooze[best] = t + RULES.askEvery;
    return best;
  }
  function later(need, t) { st.snooze[need] = t + RULES.laterSnooze; }

  function mood() {
    const vals = Object.values(st.meters), avg = vals.reduce((a, b) => a + b, 0) / vals.length;
    if (vals.some(v => v < RULES.mopeyBelow) || avg < RULES.mopeyAverage) return 'mopey';
    if (Object.keys(NEEDS).some(k => st.meters[k] < NEEDS[k].askAt)) return 'needy';
    return 'happy';
  }

  function setVacation(on, t) {
    tick(t);
    st.vacation = !!on;
    if (on) for (const k in NEEDS) st.meters[k] = Math.max(st.meters[k], RULES.vacationFloor);
  }

  // a day counts toward the streak when he was fed and taken out at least twice
  const careDay = d => d.food >= 2 && d.potty >= 2;
  function streak() {
    const byDate = new Map(st.history.map(h => [h.date, h]));
    const today = summarize(st.day, false);
    let n = careDay(today.actions) ? 1 : 0;
    for (let key = prevDay(st.day.date); ; key = prevDay(key)) {
      const h = byDate.get(key);
      if (!h) break;
      if (h.vacation) continue;
      if (!careDay(h.actions)) break;
      n++;
    }
    return n;
  }

  function score() {
    const s = summarize(st.day, false);
    const st7 = streak();
    s.categories.consistency = Math.round(Math.min(100, st7 * 100 / RULES.streakFull));
    s.score = Math.round(Object.keys(WEIGHTS).reduce((a, k) => a + WEIGHTS[k] * s.categories[k], 0));
    s.streak = st7;
    return s;
  }

  // per-day record without the streak; score() adds Consistency and the overall score
  function summarize(d, vacation) {
    const need = k => {
      const avg = d.awakeMs > 0 ? d.level[k] / d.awakeMs : st.meters[k];
      const care = Math.min(1, avg / RULES.goodAverage);
      const timely = d.counted[k] ? d.timely[k] / d.counted[k] : RULES.idleTimely;
      return 100 * (RULES.careWeight * care + (1 - RULES.careWeight) * timely);
    };
    const meals = d.good + d.junk, quality = meals ? 1 - .4 * d.junk / meals : 1;
    const categories = {
      nutrition: Math.round(.6 * need('food') * quality + .4 * need('water')),
      potty: Math.round(Math.max(0, need('potty') - RULES.accidentPenalty * d.accidents)),
      play: Math.round(need('play')),
      sleep: Math.round(need('sleep')),
      affection: Math.round(need('affection')),
      consistency: 0,
    };
    const s = Math.round(Object.keys(WEIGHTS).reduce((a, k) => a + WEIGHTS[k] * categories[k], 0));
    return { date: d.date, score: s, categories, actions: { ...d.acts }, accidents: d.accidents, vacation,
      fetches: d.fetches, zoomies: d.zoomies, firstMeal: d.firstMeal, bedtime: d.bedtime, waterLow: d.waterLow };
  }

  // days in a row (ending today) that pass pred. Today only breaks the run if broken(today) says it can't pass any more
  function run(pred, broken = () => false) {
    const days = [...st.history, summarize(st.day, false)];
    let n = 0, i = days.length - 1;
    if (!pred(days[i])) { if (broken(days[i])) return 0; i--; }
    for (; i >= 0; i--) { const d = days[i]; if (d.vacation) continue; if (!pred(d)) break; n++; }
    return n;
  }
  const view = { get totals() { return st.totals; }, run, streak };
  function badges() {
    return BADGES.map(b => {
      const value = b.soon ? 0 : Math.min(b.goal, b.value(view));
      return { id: b.id, name: b.name, icon: b.icon, how: b.how, goal: b.goal, soon: b.soon || null, value, unlocked: st.badges[b.id] || null };
    });
  }
  // badges earned just now (each one only once; an earned badge stays earned)
  function newBadges(t) {
    const out = [];
    for (const b of badges()) if (!b.soon && !b.unlocked && b.value >= b.goal) { st.badges[b.id] = dayKey(t); out.push({ ...b, unlocked: st.badges[b.id] }); }
    return out;
  }
  // the last n days' scores, oldest first, with today live; days with no record are null
  function trend(n = 7) {
    const byDate = new Map(st.history.map(h => [h.date, h]));
    const out = new Array(n);
    let key = st.day.date;
    for (let i = n - 1; i >= 0; i--, key = prevDay(key)) {
      const h = i === n - 1 ? score() : byDate.get(key);
      out[i] = { date: key, score: h && !h.vacation && (i === n - 1 || active(h)) ? h.score : null, vacation: !!(h && h.vacation), today: i === n - 1 };
    }
    return out;
  }

  return {
    tick, act, dueAsk, later, mood, setVacation, score, streak, badges, newBadges, trend,
    get meters() { return st.meters; }, get vacation() { return st.vacation; }, get history() { return st.history; },
    get today() { return st.day; }, get totals() { return st.totals; }, get born() { return st.born; },
    save() { return JSON.parse(JSON.stringify(st)); },
  };
}

function tier(score) {
  let i = 0; while (i + 1 < TIERS.length && score >= TIERS[i + 1][0]) i++;
  const next = TIERS[i + 1];
  return { name: TIERS[i][1], level: i, next: next ? { name: next[1], at: next[0], need: next[0] - score } : null };
}

const Care = { NEEDS, WEIGHTS, RULES, CATEGORY_LABELS, TIERS, BADGES, tier, create, dayKey };
if (typeof module !== 'undefined' && module.exports) module.exports = Care;
else root.Care = Care;
})(typeof window !== 'undefined' ? window : globalThis);
